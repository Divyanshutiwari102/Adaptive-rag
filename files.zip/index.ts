// ─── Auth ─────────────────────────────────────────────────────────────────────

export interface TokenResponse {
  accessToken: string;
  refreshToken: string;
  accessExpiresInMs: number;
  tokenType: string;
}

export interface SignupRequest {
  name: string;
  email: string;
  password: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RefreshRequest {
  refreshToken: string;
}

// ─── User ─────────────────────────────────────────────────────────────────────

export interface AuthUser {
  email: string;
  name?: string;
  accessToken: string;
  refreshToken: string;
  accessExpiresAt: number; // Unix ms timestamp
}

// ─── Documents ────────────────────────────────────────────────────────────────

export type IngestionStatus = 'PENDING' | 'PROCESSING' | 'DONE' | 'FAILED';

export interface DocumentSummary {
  id: string;
  filename: string;
  fileType: string;
  totalChunks: number;
  ingestionStatus: IngestionStatus;
  ingestionError: string | null;
  originalDescription: string;
  uploadedAt: string;
}

export interface IngestResponse {
  id: string;
  filename: string;
  fileType: string;
  ingestionStatus: string;
  uploadedAt: string;
  message: string;
}

export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
  first: boolean;
  last: boolean;
}

// ─── RAG ──────────────────────────────────────────────────────────────────────

export type QueryRoute = 'GENERAL' | 'INDEX';

export interface AskRequest {
  query: string;
  sessionId: string;
}

export interface AskResponse {
  queryId: string;
  sessionId: string;
  query: string;
  answer: string;
  routeTaken: QueryRoute;
  queryRewritten: boolean;
  rewrittenQuery: string | null;
  latencyMs: number;
  totalTokens: number;
  estimatedCostUsd: number;
}

export interface HistorySummary {
  id: string;
  sessionId: string;
  query: string;
  answer: string;
  routeTaken: QueryRoute;
  queryRewritten: boolean;
  latencyMs: number;
  createdAt: string;
}

export interface HistoryDetail {
  id: string;
  sessionId: string;
  originalQuery: string;
  rewrittenQuery: string | null;
  retrievedContext: string | null;
  finalAnswer: string;
  routeTaken: QueryRoute;
  retrievalGradePass: boolean | null;
  queryRewritten: boolean;
  latencyMs: number;
  createdAt: string;
}

export interface CostSummary {
  periodMonth: string;
  totalTokens: number;
  totalCostUsd: number;
  todayCostUsd: number;
}

// ─── Chat Store ───────────────────────────────────────────────────────────────

export interface MessageMetadata {
  routeTaken: QueryRoute;
  latencyMs: number;
  totalTokens: number;
  estimatedCostUsd: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
  metadata?: MessageMetadata;
  timestamp: number;
}
