import { create } from 'zustand';
import { ChatMessage, MessageMetadata } from '@/types';
import { v4 as uuidv4 } from 'uuid';

interface ChatState {
  sessionId: string;
  messages: ChatMessage[];
  isStreaming: boolean;

  initSession: () => void;
  newChat: () => void;
  addMessage: (msg: Omit<ChatMessage, 'id' | 'timestamp'>) => string;
  appendToken: (id: string, token: string) => void;
  finalizeMessage: (id: string, metadata?: MessageMetadata) => void;
  setStreaming: (v: boolean) => void;
  clearMessages: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  sessionId: '',
  messages: [],
  isStreaming: false,

  initSession: () => {
    if (!get().sessionId) {
      set({ sessionId: uuidv4() });
    }
  },

  newChat: () => {
    set({ sessionId: uuidv4(), messages: [], isStreaming: false });
  },

  addMessage: (msg) => {
    const id = uuidv4();
    const full: ChatMessage = { ...msg, id, timestamp: Date.now() };
    set((s) => ({ messages: [...s.messages, full] }));
    return id;
  },

  appendToken: (id, token) => {
    set((s) => ({
      messages: s.messages.map((m) =>
        m.id === id ? { ...m, content: m.content + token } : m
      ),
    }));
  },

  finalizeMessage: (id, metadata) => {
    set((s) => ({
      messages: s.messages.map((m) =>
        m.id === id ? { ...m, isStreaming: false, metadata } : m
      ),
      isStreaming: false,
    }));
  },

  setStreaming: (v) => set({ isStreaming: v }),

  clearMessages: () => set({ messages: [] }),
}));
