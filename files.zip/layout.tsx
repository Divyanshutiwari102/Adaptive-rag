'use client';

import './globals.css';
import { useEffect } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { Toaster } from 'sonner';
import { injectAuthStore } from '@/api/client';
import { useAuthStore } from '@/store/authStore';

function AuthStoreInjector({ children }: { children: React.ReactNode }) {
  const store = useAuthStore();

  useEffect(() => {
    injectAuthStore(() => ({
      accessToken: store.accessToken,
      refreshToken: store.refreshToken,
      setTokens: store.setTokens,
      logout: store.logout,
    }));
  }, [store]);

  return <>{children}</>;
}

function ThemeInitializer() {
  useEffect(() => {
    const saved = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const theme = saved ?? (prefersDark ? 'dark' : 'light');
    document.documentElement.classList.toggle('dark', theme === 'dark');
  }, []);
  return null;
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>AdaptiveRAG</title>
        <meta name="description" content="Intelligent document Q&A with adaptive retrieval" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,300&family=DM+Mono:wght@300;400;500&display=swap" rel="stylesheet" />
      </head>
      <body>
        <ThemeInitializer />
        <QueryClientProvider client={queryClient}>
          <AuthStoreInjector>
            {children}
            <Toaster
              position="top-right"
              toastOptions={{
                style: {
                  background: 'var(--surface)',
                  border: '1px solid var(--border)',
                  color: 'var(--text-primary)',
                  fontFamily: 'DM Sans, sans-serif',
                  fontSize: '14px',
                },
              }}
            />
          </AuthStoreInjector>
        </QueryClientProvider>
      </body>
    </html>
  );
}
