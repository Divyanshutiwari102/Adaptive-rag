import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface AuthState {
  accessToken: string | null;
  refreshToken: string | null;
  accessExpiresAt: number | null; // Unix ms
  userEmail: string | null;
  userName: string | null;

  setTokens: (access: string, refresh: string, expiresInMs: number) => void;
  setUser: (email: string, name?: string) => void;
  logout: () => void;
  isAuthenticated: () => boolean;
  isTokenExpiringSoon: () => boolean;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      accessToken: null,
      refreshToken: null,
      accessExpiresAt: null,
      userEmail: null,
      userName: null,

      setTokens: (access, refresh, expiresInMs) => {
        set({
          accessToken: access,
          refreshToken: refresh,
          accessExpiresAt: Date.now() + expiresInMs,
        });
      },

      setUser: (email, name) => {
        set({ userEmail: email, userName: name });
      },

      logout: () => {
        set({
          accessToken: null,
          refreshToken: null,
          accessExpiresAt: null,
          userEmail: null,
          userName: null,
        });
      },

      isAuthenticated: () => !!get().accessToken,

      isTokenExpiringSoon: () => {
        const expiresAt = get().accessExpiresAt;
        if (!expiresAt) return true;
        return expiresAt - Date.now() < 60_000; // < 60 seconds
      },
    }),
    {
      name: 'adaptive-rag-auth',
      storage: createJSONStorage(() =>
        typeof window !== 'undefined' ? localStorage : { getItem: () => null, setItem: () => {}, removeItem: () => {} }
      ),
    }
  )
);
