import apiClient from './client';
import {
  AskRequest,
  AskResponse,
  CostSummary,
  HistoryDetail,
  HistorySummary,
  PageResponse,
} from '@/types';

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';

export const ragApi = {
  ask: (data: AskRequest) =>
    apiClient.post<AskResponse>('/api/rag/ask', data).then((r) => r.data),

  /**
   * Streaming ask — returns a ReadableStream of tokens.
   * Caller receives raw text tokens; [DONE] signals end-of-stream.
   */
  askStream: async (
    data: AskRequest,
    accessToken: string,
    onToken: (token: string) => void,
    onDone: () => void,
    onError: (err: Error) => void
  ) => {
    try {
      const response = await fetch(`${BASE_URL}/api/rag/ask/stream`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error(`Stream request failed: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });

        // Process complete lines
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? ''; // Keep incomplete last line in buffer

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;

          const payload = trimmed.slice(5).trim();
          if (payload === '[DONE]') {
            onDone();
            return;
          }
          if (payload) {
            onToken(payload);
          }
        }
      }

      onDone();
    } catch (err) {
      onError(err instanceof Error ? err : new Error(String(err)));
    }
  },

  getHistory: (params: { sessionId?: string; page?: number; size?: number }) =>
    apiClient
      .get<PageResponse<HistorySummary>>('/api/rag/history', { params })
      .then((r) => r.data),

  getHistoryById: (id: string) =>
    apiClient.get<HistoryDetail>(`/api/rag/history/${id}`).then((r) => r.data),

  getCostCurrentMonth: () =>
    apiClient.get<CostSummary>('/api/rag/cost/current-month').then((r) => r.data),
};
