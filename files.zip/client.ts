import axios, { AxiosInstance, AxiosRequestConfig, InternalAxiosRequestConfig } from 'axios';

const BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080';

// We use a lazy import of authStore to avoid circular deps
let getAuthStore: () => {
  accessToken: string | null;
  refreshToken: string | null;
  setTokens: (access: string, refresh: string, expiresInMs: number) => void;
  logout: () => void;
} | null = () => null;

export function injectAuthStore(store: typeof getAuthStore) {
  getAuthStore = store;
}

// ── Refresh lock (prevents concurrent refresh storms) ─────────────────────────
let isRefreshing = false;
let refreshQueue: Array<(token: string) => void> = [];

function processQueue(token: string) {
  refreshQueue.forEach((cb) => cb(token));
  refreshQueue = [];
}

// ── Axios instance ─────────────────────────────────────────────────────────────
const apiClient: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: { 'Content-Type': 'application/json' },
  timeout: 15000,
});

// ── Request interceptor — attach Bearer token ──────────────────────────────────
apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  const store = getAuthStore();
  if (store?.accessToken) {
    config.headers.Authorization = `Bearer ${store.accessToken}`;
  }
  return config;
});

// ── Response interceptor — handle 401 with refresh ────────────────────────────
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    const original = error.config as AxiosRequestConfig & { _retry?: boolean };
    const store = getAuthStore();

    if (error.response?.status === 401 && !original._retry && store?.refreshToken) {
      original._retry = true;

      if (isRefreshing) {
        // Queue this request until refresh completes
        return new Promise((resolve) => {
          refreshQueue.push((newToken: string) => {
            if (original.headers) {
              original.headers['Authorization'] = `Bearer ${newToken}`;
            }
            resolve(apiClient(original));
          });
        });
      }

      isRefreshing = true;

      try {
        const { data } = await axios.post(`${BASE_URL}/auth/refresh`, {
          refreshToken: store.refreshToken,
        });

        store.setTokens(data.accessToken, data.refreshToken, data.accessExpiresInMs);
        processQueue(data.accessToken);

        if (original.headers) {
          original.headers['Authorization'] = `Bearer ${data.accessToken}`;
        }

        return apiClient(original);
      } catch {
        store.logout();
        if (typeof window !== 'undefined') {
          window.location.href = '/login';
        }
        return Promise.reject(error);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);

export default apiClient;
