'use client';

import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Upload, FileText, CheckCircle2, Clock, XCircle,
  Loader2, Trash2, Search, ChevronLeft, ChevronRight,
  RefreshCw, AlertCircle,
} from 'lucide-react';
import { toast } from 'sonner';
import { documentApi } from '@/api/documents';
import { DashboardContent } from '@/components/layout/DashboardContent';
import { IngestionStatus, DocumentSummary } from '@/types';

const PAGE_SIZE = 10;

/* ── Status badge ──────────────────────────────────────────────────────────── */
const STATUS_MAP: Record<IngestionStatus, { label: string; icon: React.ElementType; cls: string }> = {
  DONE:       { label: 'Ready',      icon: CheckCircle2, cls: 'status--done'       },
  PROCESSING: { label: 'Processing', icon: Loader2,      cls: 'status--processing' },
  PENDING:    { label: 'Pending',    icon: Clock,        cls: 'status--pending'    },
  FAILED:     { label: 'Failed',     icon: XCircle,      cls: 'status--failed'     },
};

function StatusBadge({ status }: { status: IngestionStatus }) {
  const { label, icon: Icon, cls } = STATUS_MAP[status];
  const spinning = status === 'PROCESSING';
  return (
    <span className={`status-badge ${cls}`}>
      <Icon size={11} className={spinning ? 'spin' : ''} />
      {label}
    </span>
  );
}

/* ── File type pill ────────────────────────────────────────────────────────── */
function FileTypePill({ type }: { type: string }) {
  return <span className="filetype-pill">{type.toUpperCase()}</span>;
}

/* ── Drop zone ─────────────────────────────────────────────────────────────── */
function DropZone({ onUpload }: { onUpload: (files: File[]) => void }) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop: onUpload,
    accept: {
      'application/pdf': ['.pdf'],
      'text/plain': ['.txt'],
      'text/markdown': ['.md'],
      'application/msword': ['.doc'],
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
    },
    maxSize: 50 * 1024 * 1024, // 50MB
    multiple: true,
  });

  return (
    <div
      {...getRootProps()}
      className={`dropzone ${isDragActive ? 'dropzone--active' : ''}`}
      role="button"
      tabIndex={0}
      aria-label="Upload documents"
    >
      <input {...getInputProps()} />
      <div className="dropzone-icon">
        <Upload size={20} />
      </div>
      <p className="dropzone-title">
        {isDragActive ? 'Drop files here' : 'Upload documents'}
      </p>
      <p className="dropzone-sub">
        PDF, TXT, MD, DOC, DOCX · up to 50MB each
      </p>
    </div>
  );
}

/* ── Document row ──────────────────────────────────────────────────────────── */
function DocRow({ doc, onDelete }: { doc: DocumentSummary; onDelete: (id: string) => void }) {
  const date = new Date(doc.uploadedAt).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
  });

  return (
    <tr className="doc-row">
      <td className="doc-cell doc-cell--name">
        <div className="doc-name-wrap">
          <FileText size={14} className="doc-file-icon" />
          <div>
            <p className="doc-filename">{doc.filename}</p>
            {doc.originalDescription && (
              <p className="doc-desc">{doc.originalDescription}</p>
            )}
          </div>
        </div>
      </td>
      <td className="doc-cell">
        <FileTypePill type={doc.fileType} />
      </td>
      <td className="doc-cell doc-cell--num">{doc.totalChunks.toLocaleString()}</td>
      <td className="doc-cell">
        <StatusBadge status={doc.ingestionStatus} />
      </td>
      <td className="doc-cell doc-cell--date">{date}</td>
      <td className="doc-cell doc-cell--actions">
        <button
          className="del-btn"
          onClick={() => onDelete(doc.id)}
          aria-label={`Delete ${doc.filename}`}
          title="Delete document"
        >
          <Trash2 size={13} />
        </button>
      </td>
    </tr>
  );
}

/* ── Error state ───────────────────────────────────────────────────────────── */
function ErrorState({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="error-state">
      <AlertCircle size={28} />
      <p>Failed to load documents</p>
      <button className="retry-btn" onClick={onRetry}>
        <RefreshCw size={13} /> Retry
      </button>
    </div>
  );
}

/* ── Documents page ────────────────────────────────────────────────────────── */
export default function DocumentsPage() {
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const qc = useQueryClient();

  const { data, isLoading, isError, refetch } = useQuery({
    queryKey: ['documents', page],
    queryFn: () => documentApi.list({ page, size: PAGE_SIZE }),
  });

  const uploadMutation = useMutation({
    mutationFn: (files: File[]) =>
      Promise.all(files.map((f) => documentApi.upload(f))),
    onSuccess: (results) => {
      toast.success(`${results.length} file${results.length > 1 ? 's' : ''} uploaded`);
      qc.invalidateQueries({ queryKey: ['documents'] });
    },
    onError: () => toast.error('Upload failed'),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => documentApi.delete(id),
    onSuccess: () => {
      toast.success('Document deleted');
      qc.invalidateQueries({ queryKey: ['documents'] });
    },
    onError: () => toast.error('Delete failed'),
  });

  const handleUpload = useCallback(
    (files: File[]) => uploadMutation.mutate(files),
    [uploadMutation]
  );

  const docs = data?.content ?? [];
  const filtered = search
    ? docs.filter((d) => d.filename.toLowerCase().includes(search.toLowerCase()))
    : docs;

  const totalPages = data?.totalPages ?? 1;
  const totalElements = data?.totalElements ?? 0;

  return (
    <DashboardContent title="Documents">
      <div className="docs-root">
        {/* Upload zone */}
        <DropZone onUpload={handleUpload} />

        {/* Upload progress indicator */}
        {uploadMutation.isPending && (
          <div className="upload-progress">
            <Loader2 size={14} className="spin" />
            Uploading {uploadMutation.variables?.length} file(s)…
          </div>
        )}

        {/* Table card */}
        <div className="table-card">
          {/* Table header */}
          <div className="table-topbar">
            <div className="table-meta">
              <h2 className="table-title">All Documents</h2>
              {!isLoading && (
                <span className="table-count">{totalElements.toLocaleString()} total</span>
              )}
            </div>
            <div className="table-controls">
              <div className="search-wrap">
                <Search size={13} className="search-icon" />
                <input
                  type="text"
                  className="search-input"
                  placeholder="Filter by name…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  aria-label="Filter documents"
                />
              </div>
              <button
                className="refresh-btn"
                onClick={() => refetch()}
                title="Refresh"
                aria-label="Refresh document list"
              >
                <RefreshCw size={13} />
              </button>
            </div>
          </div>

          {/* Table body */}
          {isError ? (
            <ErrorState onRetry={refetch} />
          ) : isLoading ? (
            <div className="skeleton-rows">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="skeleton-row" style={{ animationDelay: `${i * 0.06}s` }} />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty-docs">
              <FileText size={28} />
              <p>{search ? 'No documents match your filter' : 'No documents yet — upload one above'}</p>
            </div>
          ) : (
            <div className="table-scroll">
              <table className="docs-table">
                <thead>
                  <tr>
                    <th className="th">Name</th>
                    <th className="th">Type</th>
                    <th className="th th--num">Chunks</th>
                    <th className="th">Status</th>
                    <th className="th th--date">Uploaded</th>
                    <th className="th th--actions" />
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((doc) => (
                    <DocRow
                      key={doc.id}
                      doc={doc}
                      onDelete={(id) => deleteMutation.mutate(id)}
                    />
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && !isError && (
            <div className="pagination">
              <span className="pagination-info">
                Page {page + 1} of {totalPages}
              </span>
              <div className="pagination-btns">
                <button
                  className="pag-btn"
                  onClick={() => setPage((p) => Math.max(0, p - 1))}
                  disabled={page === 0}
                  aria-label="Previous page"
                >
                  <ChevronLeft size={14} />
                </button>
                <button
                  className="pag-btn"
                  onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
                  disabled={page >= totalPages - 1}
                  aria-label="Next page"
                >
                  <ChevronRight size={14} />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <style>{`
        .docs-root {
          max-width: 920px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Drop zone */
        .dropzone {
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          gap: 6px;
          padding: 32px 24px;
          border: 1.5px dashed var(--border);
          border-radius: var(--radius-lg);
          background: var(--surface);
          cursor: pointer;
          transition: all 0.15s ease;
          text-align: center;
        }

        .dropzone:hover, .dropzone--active {
          border-color: var(--primary);
          background: var(--primary-muted);
        }

        .dropzone-icon {
          width: 40px; height: 40px;
          border-radius: 10px;
          background: var(--primary-muted);
          display: flex; align-items: center; justify-content: center;
          color: var(--primary);
          margin-bottom: 4px;
          transition: transform 0.15s;
        }

        .dropzone:hover .dropzone-icon,
        .dropzone--active .dropzone-icon { transform: translateY(-2px); }

        .dropzone-title {
          font-family: 'Syne', sans-serif;
          font-size: 15px; font-weight: 700;
          color: var(--text-primary); letter-spacing: -0.02em;
        }

        .dropzone-sub {
          font-size: 12px; color: var(--text-tertiary);
        }

        /* Upload progress */
        .upload-progress {
          display: flex; align-items: center; gap: 8px;
          padding: 10px 14px;
          background: var(--primary-muted);
          border: 1px solid var(--primary);
          border-radius: var(--radius-md);
          font-size: 13px; color: var(--primary);
          font-weight: 500;
        }

        /* Table card */
        .table-card {
          background: var(--surface);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-lg);
          overflow: hidden;
        }

        .table-topbar {
          display: flex; align-items: center; justify-content: space-between;
          padding: 16px 20px;
          border-bottom: 1px solid var(--border-subtle);
          flex-wrap: wrap; gap: 12px;
        }

        .table-meta { display: flex; align-items: center; gap: 10px; }

        .table-title {
          font-family: 'Syne', sans-serif;
          font-size: 15px; font-weight: 700;
          color: var(--text-primary); letter-spacing: -0.02em;
        }

        .table-count {
          font-family: 'DM Mono', monospace;
          font-size: 11px; color: var(--text-tertiary);
          padding: 2px 7px;
          background: var(--surface-2);
          border-radius: 4px;
        }

        .table-controls { display: flex; align-items: center; gap: 8px; }

        .search-wrap {
          position: relative; display: flex; align-items: center;
        }

        .search-icon {
          position: absolute; left: 9px;
          color: var(--text-tertiary); pointer-events: none;
        }

        .search-input {
          padding: 6px 10px 6px 28px;
          border: 1px solid var(--border);
          border-radius: var(--radius-sm);
          background: var(--surface-2);
          color: var(--text-primary);
          font-family: 'DM Sans', sans-serif;
          font-size: 12.5px;
          outline: none;
          width: 200px;
          transition: all 0.15s;
        }

        .search-input:focus {
          border-color: var(--primary);
          box-shadow: var(--shadow-glow);
        }

        .refresh-btn {
          width: 32px; height: 32px; border-radius: var(--radius-sm);
          border: 1px solid var(--border);
          background: var(--surface-2);
          color: var(--text-tertiary);
          cursor: pointer; display: flex; align-items: center; justify-content: center;
          transition: all 0.13s;
        }

        .refresh-btn:hover { color: var(--text-primary); background: var(--surface-3); }

        /* Table */
        .table-scroll { overflow-x: auto; }

        .docs-table {
          width: 100%; border-collapse: collapse;
        }

        .th {
          padding: 10px 14px;
          text-align: left;
          font-family: 'DM Mono', monospace;
          font-size: 10px; font-weight: 500;
          letter-spacing: 0.06em; text-transform: uppercase;
          color: var(--text-tertiary);
          border-bottom: 1px solid var(--border-subtle);
          white-space: nowrap;
        }

        .th--num, .doc-cell--num { text-align: right; }
        .th--date, .th--actions { white-space: nowrap; }

        .doc-row {
          border-bottom: 1px solid var(--border-subtle);
          transition: background 0.12s;
        }

        .doc-row:last-child { border-bottom: none; }
        .doc-row:hover { background: var(--surface-2); }

        .doc-cell {
          padding: 12px 14px;
          font-size: 13px;
          color: var(--text-secondary);
          vertical-align: middle;
        }

        .doc-cell--name { width: 100%; }

        .doc-name-wrap {
          display: flex; align-items: flex-start; gap: 10px;
        }

        .doc-file-icon { color: var(--text-tertiary); flex-shrink: 0; margin-top: 1px; }

        .doc-filename {
          font-size: 13px; font-weight: 500;
          color: var(--text-primary);
          word-break: break-word;
        }

        .doc-desc {
          font-size: 11.5px; color: var(--text-tertiary);
          margin-top: 2px;
          overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
          max-width: 320px;
        }

        .doc-cell--date {
          font-family: 'DM Mono', monospace;
          font-size: 11.5px;
          color: var(--text-tertiary);
          white-space: nowrap;
        }

        .doc-cell--actions { white-space: nowrap; }

        .del-btn {
          width: 28px; height: 28px; border-radius: 6px;
          border: 1px solid transparent;
          background: transparent; color: var(--text-tertiary);
          cursor: pointer; display: flex; align-items: center; justify-content: center;
          transition: all 0.13s;
        }

        .del-btn:hover {
          background: var(--danger-muted);
          border-color: var(--danger);
          color: var(--danger);
        }

        /* Status badges */
        .status-badge {
          display: inline-flex; align-items: center; gap: 4px;
          font-family: 'DM Mono', monospace;
          font-size: 10.5px; padding: 3px 7px;
          border-radius: 4px; white-space: nowrap;
        }

        .status--done { background: rgba(0,200,160,0.1); color: var(--accent); }
        .status--processing { background: var(--primary-muted); color: var(--primary); }
        .status--pending { background: var(--warning-muted); color: var(--warning); }
        .status--failed { background: var(--danger-muted); color: var(--danger); }

        .filetype-pill {
          display: inline-block;
          font-family: 'DM Mono', monospace;
          font-size: 10px; padding: 2px 6px;
          background: var(--surface-3);
          color: var(--text-tertiary);
          border-radius: 4px;
        }

        /* Skeleton rows */
        .skeleton-rows { padding: 8px 0; }
        .skeleton-row {
          height: 52px; margin: 4px 16px;
          border-radius: var(--radius-md);
          background: linear-gradient(90deg, var(--surface-2) 25%, var(--surface-3) 50%, var(--surface-2) 75%);
          background-size: 200% 100%;
          animation: shimmer 1.6s infinite;
        }

        /* Empty / error */
        .empty-docs, .error-state {
          display: flex; flex-direction: column; align-items: center; justify-content: center;
          gap: 10px; padding: 56px 24px;
          color: var(--text-tertiary);
        }

        .empty-docs p, .error-state p { font-size: 13px; }

        .retry-btn {
          display: flex; align-items: center; gap: 6px;
          padding: 7px 14px;
          border-radius: var(--radius-sm);
          border: 1px solid var(--border);
          background: var(--surface-2);
          color: var(--text-secondary);
          font-size: 12.5px; cursor: pointer;
          transition: all 0.13s;
        }

        .retry-btn:hover { background: var(--surface-3); color: var(--text-primary); }

        /* Pagination */
        .pagination {
          display: flex; align-items: center; justify-content: space-between;
          padding: 12px 20px;
          border-top: 1px solid var(--border-subtle);
        }

        .pagination-info {
          font-family: 'DM Mono', monospace;
          font-size: 11px; color: var(--text-tertiary);
        }

        .pagination-btns { display: flex; gap: 4px; }

        .pag-btn {
          width: 30px; height: 30px; border-radius: 6px;
          border: 1px solid var(--border);
          background: var(--surface-2);
          color: var(--text-secondary);
          cursor: pointer; display: flex; align-items: center; justify-content: center;
          transition: all 0.13s;
        }

        .pag-btn:hover:not(:disabled) { background: var(--surface-3); color: var(--text-primary); }
        .pag-btn:disabled { opacity: 0.4; cursor: not-allowed; }
      `}</style>
    </DashboardContent>
  );
}
