'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { Send, RotateCcw, Zap, Route, Clock, Coins, ChevronDown } from 'lucide-react';
import { useChatStore } from '@/store/chatStore';
import { useAuthStore } from '@/store/authStore';
import { ragApi } from '@/api/rag';
import { DashboardContent } from '@/components/layout/DashboardContent';
import { MessageMetadata, QueryRoute } from '@/types';

/* ── Route badge ───────────────────────────────────────────────────────────── */
function RouteBadge({ route }: { route: QueryRoute }) {
  const isIndex = route === 'INDEX';
  return (
    <span className={`route-badge ${isIndex ? 'route-badge--index' : 'route-badge--general'}`}>
      <Route size={9} />
      {isIndex ? 'Index' : 'General'}
    </span>
  );
}

/* ── Message metadata strip ────────────────────────────────────────────────── */
function MetaStrip({ meta }: { meta: MessageMetadata }) {
  return (
    <div className="meta-strip">
      <RouteBadge route={meta.routeTaken} />
      <span className="meta-item">
        <Clock size={10} />
        {meta.latencyMs}ms
      </span>
      <span className="meta-item">
        <Zap size={10} />
        {meta.totalTokens.toLocaleString()} tokens
      </span>
      <span className="meta-item">
        <Coins size={10} />
        ${meta.estimatedCostUsd.toFixed(5)}
      </span>
    </div>
  );
}

/* ── Single message bubble ──────────────────────────────────────────────────── */
function MessageBubble({
  role,
  content,
  isStreaming,
  metadata,
}: {
  role: 'user' | 'assistant';
  content: string;
  isStreaming?: boolean;
  metadata?: MessageMetadata;
}) {
  const isUser = role === 'user';
  return (
    <div className={`message-row ${isUser ? 'message-row--user' : ''}`}>
      {!isUser && (
        <div className="bot-avatar">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="none">
            <path d="M10 2L17.3 6V14L10 18L2.7 14V6L10 2Z" fill="var(--primary)" opacity="0.9" />
            <circle cx="10" cy="11" r="2.5" fill="var(--surface)" />
          </svg>
        </div>
      )}

      <div className={`bubble ${isUser ? 'bubble--user' : 'bubble--bot'}`}>
        <p className="bubble-text">
          {content}
          {isStreaming && <span className="streaming-cursor" aria-hidden="true" />}
        </p>
        {!isUser && metadata && <MetaStrip meta={metadata} />}
      </div>
    </div>
  );
}

/* ── Empty state ───────────────────────────────────────────────────────────── */
function EmptyState({ onSuggestion }: { onSuggestion: (q: string) => void }) {
  const suggestions = [
    'What documents have been uploaded?',
    'Summarize the key points from my knowledge base',
    'What topics can you help me explore?',
    'How does the adaptive retrieval work?',
  ];

  return (
    <div className="empty-state">
      <div className="empty-icon">
        <svg width="32" height="32" viewBox="0 0 20 20" fill="none">
          <path d="M10 2L17.3 6V14L10 18L2.7 14V6L10 2Z" fill="var(--primary)" opacity="0.15" />
          <path d="M10 2L17.3 6V14L10 18L2.7 14V6L10 2Z" stroke="var(--primary)" strokeWidth="1" fill="none" />
          <circle cx="10" cy="11" r="2.5" fill="var(--primary)" opacity="0.6" />
        </svg>
      </div>
      <h2 className="empty-title">Ask anything</h2>
      <p className="empty-sub">
        Queries route automatically — indexed documents or general knowledge.
      </p>
      <div className="suggestions">
        {suggestions.map((s) => (
          <button
            key={s}
            className="suggestion-chip"
            onClick={() => onSuggestion(s)}
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Scroll-to-bottom button ───────────────────────────────────────────────── */
function ScrollAnchor({ show, onClick }: { show: boolean; onClick: () => void }) {
  if (!show) return null;
  return (
    <button className="scroll-anchor" onClick={onClick} aria-label="Scroll to bottom">
      <ChevronDown size={14} />
    </button>
  );
}

/* ── Chat page ─────────────────────────────────────────────────────────────── */
export default function ChatPage() {
  const [input, setInput] = useState('');
  const [showScrollBtn, setShowScrollBtn] = useState(false);

  const { messages, isStreaming, initSession, addMessage, appendToken, finalizeMessage, setStreaming, newChat } =
    useChatStore();
  const { accessToken } = useAuthStore();

  const bottomRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    initSession();
  }, [initSession]);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = 'smooth') => {
    bottomRef.current?.scrollIntoView({ behavior });
  }, []);

  // Auto-scroll during streaming
  useEffect(() => {
    if (isStreaming) scrollToBottom();
  }, [messages, isStreaming, scrollToBottom]);

  // Show scroll-to-bottom when user scrolls up
  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    setShowScrollBtn(distFromBottom > 120);
  };

  // Auto-grow textarea
  useEffect(() => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 160) + 'px';
  }, [input]);

  const sessionId = useChatStore((s) => s.sessionId);

  const submit = useCallback(
    async (text: string) => {
      const query = text.trim();
      if (!query || isStreaming) return;

      setInput('');

      addMessage({ role: 'user', content: query });

      const assistantId = addMessage({ role: 'assistant', content: '', isStreaming: true });
      setStreaming(true);
      scrollToBottom('instant');

      await ragApi.askStream(
        { query, sessionId },
        accessToken ?? '',
        (token) => appendToken(assistantId, token),
        () => {
          // metadata comes from non-streaming endpoint; mark done
          finalizeMessage(assistantId);
        },
        (err) => {
          finalizeMessage(assistantId);
          console.error('Stream error:', err);
        }
      );
    },
    [isStreaming, sessionId, accessToken, addMessage, appendToken, finalizeMessage, setStreaming, scrollToBottom]
  );

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit(input);
    }
  };

  return (
    <DashboardContent title="Chat">
      <div className="chat-root">
        {/* Messages */}
        <div className="messages-area" ref={scrollRef} onScroll={handleScroll}>
          {messages.length === 0 ? (
            <EmptyState onSuggestion={(q) => { setInput(q); textareaRef.current?.focus(); }} />
          ) : (
            <div className="messages-list">
              {messages.map((msg) => (
                <MessageBubble key={msg.id} {...msg} />
              ))}
              <div ref={bottomRef} />
            </div>
          )}
        </div>

        <ScrollAnchor show={showScrollBtn} onClick={() => scrollToBottom()} />

        {/* Input bar */}
        <div className="input-bar">
          <div className="input-wrapper">
            <textarea
              ref={textareaRef}
              className="chat-input"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question… (Enter to send, Shift+Enter for newline)"
              disabled={isStreaming}
              rows={1}
              aria-label="Chat input"
            />
            <div className="input-actions">
              <button
                className="reset-btn"
                onClick={newChat}
                disabled={isStreaming || messages.length === 0}
                title="New chat"
                aria-label="Start new chat"
              >
                <RotateCcw size={14} />
              </button>
              <button
                className="send-btn"
                onClick={() => submit(input)}
                disabled={!input.trim() || isStreaming}
                aria-label="Send message"
              >
                <Send size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        .chat-root {
          display: flex;
          flex-direction: column;
          height: calc(100vh - 60px - 56px); /* full height minus navbar and content padding */
          min-height: 500px;
          margin: -28px;        /* bleed to edge of dashboard content */
        }

        /* Messages */
        .messages-area {
          flex: 1;
          overflow-y: auto;
          padding: 24px 0;
          scroll-behavior: smooth;
          position: relative;
        }

        .messages-list {
          max-width: 760px;
          margin: 0 auto;
          padding: 0 24px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Empty state */
        .empty-state {
          max-width: 480px;
          margin: 80px auto 0;
          padding: 0 24px;
          text-align: center;
        }

        .empty-icon {
          display: flex;
          justify-content: center;
          margin-bottom: 16px;
        }

        .empty-title {
          font-family: 'Syne', sans-serif;
          font-size: 22px;
          font-weight: 700;
          color: var(--text-primary);
          letter-spacing: -0.03em;
          margin-bottom: 8px;
        }

        .empty-sub {
          font-size: 14px;
          color: var(--text-secondary);
          line-height: 1.6;
          margin-bottom: 28px;
        }

        .suggestions {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          justify-content: center;
        }

        .suggestion-chip {
          padding: 7px 14px;
          border-radius: 99px;
          border: 1px solid var(--border);
          background: var(--surface);
          color: var(--text-secondary);
          font-size: 12.5px;
          cursor: pointer;
          transition: all 0.15s ease;
          text-align: left;
        }

        .suggestion-chip:hover {
          border-color: var(--primary);
          color: var(--primary);
          background: var(--primary-muted);
        }

        /* Message rows */
        .message-row {
          display: flex;
          align-items: flex-start;
          gap: 10px;
          animation: fadeIn 0.2s ease;
        }

        .message-row--user {
          flex-direction: row-reverse;
        }

        .bot-avatar {
          width: 30px;
          height: 30px;
          border-radius: 9px;
          background: var(--primary-muted);
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          margin-top: 2px;
        }

        /* Bubbles */
        .bubble {
          max-width: 72%;
          border-radius: 14px;
          padding: 12px 15px;
        }

        .bubble--user {
          background: var(--primary);
          color: #fff;
          border-bottom-right-radius: 4px;
        }

        .bubble--bot {
          background: var(--surface);
          border: 1px solid var(--border-subtle);
          color: var(--text-primary);
          border-bottom-left-radius: 4px;
        }

        .bubble-text {
          font-size: 14px;
          line-height: 1.65;
          white-space: pre-wrap;
          word-break: break-word;
        }

        /* Streaming cursor */
        .streaming-cursor::after {
          content: '▋';
          display: inline-block;
          animation: blink 0.7s step-end infinite;
          color: var(--primary);
          margin-left: 2px;
          font-size: 12px;
        }

        @keyframes blink { 0%,100% { opacity:1; } 50% { opacity:0; } }

        /* Meta strip */
        .meta-strip {
          display: flex;
          align-items: center;
          gap: 10px;
          margin-top: 8px;
          padding-top: 8px;
          border-top: 1px solid var(--border-subtle);
          flex-wrap: wrap;
        }

        .meta-item {
          display: flex;
          align-items: center;
          gap: 3px;
          font-family: 'DM Mono', monospace;
          font-size: 10px;
          color: var(--text-tertiary);
        }

        .route-badge {
          display: inline-flex;
          align-items: center;
          gap: 3px;
          font-family: 'DM Mono', monospace;
          font-size: 10px;
          padding: 2px 6px;
          border-radius: 4px;
        }

        .route-badge--index {
          background: var(--primary-muted);
          color: var(--primary);
        }

        .route-badge--general {
          background: var(--accent-muted, rgba(0,200,160,0.1));
          color: var(--accent);
        }

        /* Scroll-to-bottom */
        .scroll-anchor {
          position: absolute;
          bottom: 100px;
          left: 50%;
          transform: translateX(-50%);
          width: 32px;
          height: 32px;
          border-radius: 99px;
          background: var(--surface);
          border: 1px solid var(--border);
          box-shadow: var(--shadow-md);
          display: flex;
          align-items: center;
          justify-content: center;
          color: var(--text-secondary);
          cursor: pointer;
          z-index: 10;
          transition: all 0.15s;
        }

        .scroll-anchor:hover {
          background: var(--surface-2);
          color: var(--text-primary);
        }

        /* Input bar */
        .input-bar {
          flex-shrink: 0;
          padding: 12px 24px 20px;
          background: var(--bg);
        }

        .input-wrapper {
          max-width: 760px;
          margin: 0 auto;
          display: flex;
          align-items: flex-end;
          gap: 8px;
          background: var(--surface);
          border: 1px solid var(--border);
          border-radius: 14px;
          padding: 10px 10px 10px 16px;
          box-shadow: var(--shadow-sm);
          transition: border-color 0.15s, box-shadow 0.15s;
        }

        .input-wrapper:focus-within {
          border-color: var(--primary);
          box-shadow: var(--shadow-glow);
        }

        .chat-input {
          flex: 1;
          border: none;
          background: transparent;
          font-family: 'DM Sans', sans-serif;
          font-size: 14px;
          color: var(--text-primary);
          resize: none;
          outline: none;
          line-height: 1.5;
          max-height: 160px;
          overflow-y: auto;
        }

        .chat-input::placeholder { color: var(--text-tertiary); }
        .chat-input:disabled { opacity: 0.6; cursor: not-allowed; }

        .input-actions {
          display: flex;
          align-items: center;
          gap: 6px;
          flex-shrink: 0;
        }

        .reset-btn {
          width: 32px;
          height: 32px;
          border-radius: 8px;
          border: 1px solid var(--border-subtle);
          background: transparent;
          color: var(--text-tertiary);
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.13s;
        }

        .reset-btn:hover:not(:disabled) {
          background: var(--surface-2);
          color: var(--text-secondary);
        }

        .reset-btn:disabled { opacity: 0.4; cursor: not-allowed; }

        .send-btn {
          width: 34px;
          height: 34px;
          border-radius: 9px;
          border: none;
          background: var(--primary);
          color: #fff;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.13s;
        }

        .send-btn:hover:not(:disabled) {
          background: var(--primary-hover);
          transform: scale(1.04);
        }

        .send-btn:disabled {
          opacity: 0.4;
          cursor: not-allowed;
          transform: none;
        }

        @media (max-width: 768px) {
          .chat-root { margin: -20px -16px; }
          .messages-list { padding: 0 16px; }
          .input-bar { padding: 10px 16px 16px; }
          .bubble { max-width: 88%; }
        }
      `}</style>
    </DashboardContent>
  );
}
