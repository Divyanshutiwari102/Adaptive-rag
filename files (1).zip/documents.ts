import apiClient from './client';
import { DocumentSummary, IngestResponse, PageResponse } from '@/types';

export const documentApi = {
  list: (params: { page?: number; size?: number }) =>
    apiClient
      .get<PageResponse<DocumentSummary>>('/api/documents', { params })
      .then((r) => r.data),

  upload: (file: File) => {
    const form = new FormData();
    form.append('file', file);
    return apiClient
      .post<IngestResponse>('/api/documents/ingest', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      .then((r) => r.data);
  },

  delete: (id: string) =>
    apiClient.delete(`/api/documents/${id}`).then((r) => r.data),

  getById: (id: string) =>
    apiClient.get<DocumentSummary>(`/api/documents/${id}`).then((r) => r.data),
};
