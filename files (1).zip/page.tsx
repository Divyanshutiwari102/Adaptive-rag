'use client';

import { useQuery } from '@tanstack/react-query';
import {
  MessageSquare, FileText, Coins, Zap,
  ArrowRight, Route, Clock, TrendingUp,
} from 'lucide-react';
import Link from 'next/link';
import { ragApi } from '@/api/rag';
import { documentApi } from '@/api/documents';
import { DashboardContent } from '@/components/layout/DashboardContent';
import { HistorySummary, QueryRoute } from '@/types';

/* ── Stat card ─────────────────────────────────────────────────────────────── */
function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ElementType;
  accent?: 'primary' | 'accent' | 'warning';
}) {
  const accentVar = {
    primary: 'var(--primary)',
    accent: 'var(--accent)',
    warning: 'var(--warning)',
  }[accent ?? 'primary'];

  return (
    <div className="stat-card">
      <div className="stat-icon" style={{ background: `color-mix(in srgb, ${accentVar} 12%, transparent)`, color: accentVar }}>
        <Icon size={16} />
      </div>
      <div className="stat-body">
        <p className="stat-label">{label}</p>
        <p className="stat-value">{value}</p>
        {sub && <p className="stat-sub">{sub}</p>}
      </div>
    </div>
  );
}

/* ── Route chip ────────────────────────────────────────────────────────────── */
function RouteChip({ route }: { route: QueryRoute }) {
  return (
    <span className={`route-chip ${route === 'INDEX' ? 'route-chip--index' : 'route-chip--general'}`}>
      <Route size={9} />
      {route === 'INDEX' ? 'Index' : 'General'}
    </span>
  );
}

/* ── History row ───────────────────────────────────────────────────────────── */
function HistoryRow({ item }: { item: HistorySummary }) {
  const date = new Date(item.createdAt).toLocaleTimeString('en-GB', {
    hour: '2-digit', minute: '2-digit',
  });

  return (
    <div className="history-row">
      <div className="history-main">
        <p className="history-query">{item.query}</p>
        <p className="history-answer">{item.answer}</p>
      </div>
      <div className="history-meta">
        <RouteChip route={item.routeTaken} />
        <span className="history-stat">
          <Clock size={10} />{item.latencyMs}ms
        </span>
        <span className="history-time">{date}</span>
      </div>
    </div>
  );
}

/* ── Section header ────────────────────────────────────────────────────────── */
function SectionHeader({ title, href, linkLabel }: { title: string; href?: string; linkLabel?: string }) {
  return (
    <div className="section-header">
      <h2 className="section-title">{title}</h2>
      {href && (
        <Link href={href} className="section-link">
          {linkLabel ?? 'View all'} <ArrowRight size={12} />
        </Link>
      )}
    </div>
  );
}

/* ── Skeleton ──────────────────────────────────────────────────────────────── */
function Skeleton({ h = 20, w = '100%' }: { h?: number; w?: string }) {
  return (
    <div
      className="skeleton"
      style={{ height: h, width: w, borderRadius: 6 }}
      aria-hidden="true"
    />
  );
}

/* ── Overview page ─────────────────────────────────────────────────────────── */
export default function OverviewPage() {
  const { data: cost, isLoading: costLoading } = useQuery({
    queryKey: ['cost'],
    queryFn: ragApi.getCostCurrentMonth,
    staleTime: 60_000,
  });

  const { data: docs, isLoading: docsLoading } = useQuery({
    queryKey: ['documents', 0],
    queryFn: () => documentApi.list({ page: 0, size: 1 }),
    staleTime: 30_000,
  });

  const { data: history, isLoading: historyLoading } = useQuery({
    queryKey: ['history', 'overview'],
    queryFn: () => ragApi.getHistory({ page: 0, size: 6 }),
    staleTime: 30_000,
  });

  const totalDocs = docs?.totalElements ?? 0;
  const totalTokens = cost?.totalTokens ?? 0;
  const totalCost = cost?.totalCostUsd ?? 0;
  const todayCost = cost?.todayCostUsd ?? 0;
  const historyItems = history?.content ?? [];
  const totalQueries = history?.totalElements ?? 0;

  return (
    <DashboardContent title="Overview">
      <div className="overview-root">

        {/* Stat cards */}
        <div className="stats-grid">
          {costLoading || docsLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="stat-card">
                <Skeleton h={36} w="36px" />
                <div style={{ flex: 1 }}>
                  <Skeleton h={10} w="60%" />
                  <Skeleton h={22} w="40%" />
                </div>
              </div>
            ))
          ) : (
            <>
              <StatCard
                label="Documents"
                value={totalDocs.toLocaleString()}
                sub="in knowledge base"
                icon={FileText}
                accent="primary"
              />
              <StatCard
                label="Total Queries"
                value={totalQueries.toLocaleString()}
                sub="this month"
                icon={MessageSquare}
                accent="accent"
              />
              <StatCard
                label="Tokens Used"
                value={totalTokens.toLocaleString()}
                sub="this month"
                icon={Zap}
                accent="warning"
              />
              <StatCard
                label="Monthly Cost"
                value={`$${totalCost.toFixed(4)}`}
                sub={`$${todayCost.toFixed(4)} today`}
                icon={Coins}
                accent="primary"
              />
            </>
          )}
        </div>

        {/* Recent queries */}
        <div className="section-card">
          <SectionHeader title="Recent Queries" href="/dashboard/chat" linkLabel="Open chat" />

          {historyLoading ? (
            <div className="history-list">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="history-row">
                  <div className="history-main" style={{ gap: 6 }}>
                    <Skeleton h={14} w="70%" />
                    <Skeleton h={10} w="90%" />
                  </div>
                </div>
              ))}
            </div>
          ) : historyItems.length === 0 ? (
            <div className="empty-history">
              <TrendingUp size={24} />
              <p>No queries yet — start a chat to see history here</p>
              <Link href="/dashboard/chat" className="cta-link">
                Start chatting <ArrowRight size={12} />
              </Link>
            </div>
          ) : (
            <div className="history-list">
              {historyItems.map((item) => (
                <HistoryRow key={item.id} item={item} />
              ))}
            </div>
          )}
        </div>

        {/* Quick actions */}
        <div className="quick-actions">
          <Link href="/dashboard/chat" className="action-card">
            <div className="action-icon action-icon--primary">
              <MessageSquare size={18} />
            </div>
            <div>
              <p className="action-title">Ask a question</p>
              <p className="action-sub">Start a new chat session</p>
            </div>
            <ArrowRight size={14} className="action-arrow" />
          </Link>

          <Link href="/dashboard/documents" className="action-card">
            <div className="action-icon action-icon--accent">
              <FileText size={18} />
            </div>
            <div>
              <p className="action-title">Upload documents</p>
              <p className="action-sub">Add to your knowledge base</p>
            </div>
            <ArrowRight size={14} className="action-arrow" />
          </Link>
        </div>
      </div>

      <style>{`
        .overview-root {
          max-width: 900px;
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        /* Stat cards */
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
          gap: 12px;
        }

        .stat-card {
          display: flex;
          align-items: center;
          gap: 14px;
          padding: 16px 18px;
          background: var(--surface);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-lg);
          transition: box-shadow 0.15s, border-color 0.15s;
        }

        .stat-card:hover {
          border-color: var(--border);
          box-shadow: var(--shadow-sm);
        }

        .stat-icon {
          width: 40px; height: 40px;
          border-radius: 10px;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }

        .stat-body { flex: 1; min-width: 0; }

        .stat-label {
          font-family: 'DM Mono', monospace;
          font-size: 10px; font-weight: 500;
          letter-spacing: 0.06em; text-transform: uppercase;
          color: var(--text-tertiary);
          margin-bottom: 3px;
        }

        .stat-value {
          font-family: 'Syne', sans-serif;
          font-size: 22px; font-weight: 700;
          color: var(--text-primary);
          letter-spacing: -0.03em;
          line-height: 1.1;
        }

        .stat-sub {
          font-size: 11px; color: var(--text-tertiary);
          margin-top: 2px;
        }

        /* Section card */
        .section-card {
          background: var(--surface);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-lg);
          overflow: hidden;
        }

        .section-header {
          display: flex; align-items: center; justify-content: space-between;
          padding: 16px 20px;
          border-bottom: 1px solid var(--border-subtle);
        }

        .section-title {
          font-family: 'Syne', sans-serif;
          font-size: 14px; font-weight: 700;
          color: var(--text-primary); letter-spacing: -0.02em;
        }

        .section-link {
          display: flex; align-items: center; gap: 4px;
          font-size: 12px; color: var(--primary);
          text-decoration: none; font-weight: 500;
          transition: gap 0.13s;
        }

        .section-link:hover { gap: 6px; }

        /* History */
        .history-list {
          display: flex; flex-direction: column;
        }

        .history-row {
          display: flex; align-items: flex-start;
          justify-content: space-between;
          gap: 12px;
          padding: 13px 20px;
          border-bottom: 1px solid var(--border-subtle);
          transition: background 0.12s;
          min-width: 0;
        }

        .history-row:last-child { border-bottom: none; }
        .history-row:hover { background: var(--surface-2); }

        .history-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 3px; }

        .history-query {
          font-size: 13px; font-weight: 500;
          color: var(--text-primary);
          overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        }

        .history-answer {
          font-size: 12px; color: var(--text-tertiary);
          overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        }

        .history-meta {
          display: flex; align-items: center; gap: 8px;
          flex-shrink: 0; flex-wrap: wrap; justify-content: flex-end;
        }

        .history-stat {
          display: flex; align-items: center; gap: 3px;
          font-family: 'DM Mono', monospace;
          font-size: 10px; color: var(--text-tertiary);
        }

        .history-time {
          font-family: 'DM Mono', monospace;
          font-size: 10px; color: var(--text-tertiary);
        }

        .route-chip {
          display: inline-flex; align-items: center; gap: 3px;
          font-family: 'DM Mono', monospace;
          font-size: 10px; padding: 2px 6px;
          border-radius: 4px;
        }

        .route-chip--index { background: var(--primary-muted); color: var(--primary); }
        .route-chip--general { background: rgba(0,200,160,0.1); color: var(--accent); }

        /* Empty history */
        .empty-history {
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 8px; padding: 48px 24px;
          color: var(--text-tertiary);
        }

        .empty-history p { font-size: 13px; }

        .cta-link {
          display: inline-flex; align-items: center; gap: 5px;
          padding: 7px 14px;
          border-radius: var(--radius-sm);
          background: var(--primary-muted);
          color: var(--primary);
          font-size: 12.5px; font-weight: 500;
          text-decoration: none;
          transition: all 0.13s;
        }

        .cta-link:hover { background: var(--primary); color: white; }

        /* Quick actions */
        .quick-actions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }

        .action-card {
          display: flex; align-items: center; gap: 14px;
          padding: 16px 18px;
          background: var(--surface);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-lg);
          text-decoration: none;
          transition: all 0.15s;
          cursor: pointer;
        }

        .action-card:hover {
          border-color: var(--primary);
          box-shadow: var(--shadow-sm);
          transform: translateY(-1px);
        }

        .action-icon {
          width: 40px; height: 40px;
          border-radius: 10px;
          display: flex; align-items: center; justify-content: center;
          flex-shrink: 0;
        }

        .action-icon--primary { background: var(--primary-muted); color: var(--primary); }
        .action-icon--accent { background: rgba(0,200,160,0.1); color: var(--accent); }

        .action-title {
          font-size: 13.5px; font-weight: 600;
          color: var(--text-primary); letter-spacing: -0.01em;
        }

        .action-sub {
          font-size: 11.5px; color: var(--text-tertiary); margin-top: 2px;
        }

        .action-arrow {
          color: var(--text-tertiary); margin-left: auto; flex-shrink: 0;
          transition: transform 0.15s;
        }

        .action-card:hover .action-arrow { transform: translateX(3px); color: var(--primary); }

        /* Skeleton */
        .skeleton {
          background: linear-gradient(90deg, var(--surface-2) 25%, var(--surface-3) 50%, var(--surface-2) 75%);
          background-size: 200% 100%;
          animation: shimmer 1.6s infinite;
        }

        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }

        @media (max-width: 640px) {
          .quick-actions { grid-template-columns: 1fr; }
          .stats-grid { grid-template-columns: 1fr 1fr; }
        }
      `}</style>
    </DashboardContent>
  );
}
